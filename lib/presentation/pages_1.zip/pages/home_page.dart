import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/constants/app_colors.dart';
import '../blocs/attendance/attendance_bloc.dart';
import '../blocs/attendance/attendance_event.dart';
import '../blocs/attendance/attendance_state.dart';

// class HomePage extends StatefulWidget {
//   const HomePage({super.key});
//
//   @override
//   State<HomePage> createState() => _HomePageState();
// }
//
// class _HomePageState extends State<HomePage> {
//   int _selectedWorkTypeIndex = 0; // 0: GPS, 1: WFH
//   final TextEditingController _descriptionController = TextEditingController();
//
//   @override
//   void initState() {
//     super.initState();
//     context.read<AttendanceBloc>().add(LoadTodayAttendanceEvent());
//   }
//
//   @override
//   void dispose() {
//     _descriptionController.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return BlocConsumer<AttendanceBloc, AttendanceState>(
//       listener: (context, state) {
//         if (state is AttendanceLoadedState && state.successMessage != null) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Text(state.successMessage!),
//               backgroundColor: AppColors.successEmerald,
//             ),
//           );
//         } else if (state is AttendanceErrorState) {
//           ScaffoldMessenger.of(context).showSnackBar(
//             SnackBar(
//               content: Text(state.message),
//               backgroundColor: AppColors.dangerRose,
//             ),
//           );
//         }
//       },
//       builder: (context, state) {
//         final isLoading = state is AttendanceLoadingState;
//         final todayRecord = state is AttendanceLoadedState ? state.todayRecord : null;
//         final isClockedIn = todayRecord != null && todayRecord.checkOutTime == null;
//
//         return SingleChildScrollView(
//           padding: const EdgeInsets.all(20.0),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               // Segmented Control
//               Center(
//                 child: Container(
//                   height: 48,
//                   width: 240,
//                   padding: const EdgeInsets.all(4),
//                   decoration: BoxDecoration(
//                     color: Colors.white,
//                     borderRadius: BorderRadius.circular(12),
//                     border: Border.all(color: AppColors.borderGrey),
//                   ),
//                   child: Row(
//                     children: [
//                       Expanded(
//                         child: GestureDetector(
//                           onTap: () => setState(() => _selectedWorkTypeIndex = 0),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: _selectedWorkTypeIndex == 0
//                                   ? const Color(0xFFF1F5F9)
//                                   : Colors.transparent,
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//                             alignment: Alignment.center,
//                             child: Text(
//                               'GPS',
//                               style: TextStyle(
//                                 color: _selectedWorkTypeIndex == 0
//                                     ? AppColors.textDark
//                                     : AppColors.textLight,
//                                 fontWeight: FontWeight.w600,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                       Expanded(
//                         child: GestureDetector(
//                           onTap: () => setState(() => _selectedWorkTypeIndex = 1),
//                           child: Container(
//                             decoration: BoxDecoration(
//                               color: _selectedWorkTypeIndex == 1
//                                   ? const Color(0xFFF1F5F9)
//                                   : Colors.transparent,
//                               borderRadius: BorderRadius.circular(8),
//                             ),
//                             alignment: Alignment.center,
//                             child: Text(
//                               'WFH',
//                               style: TextStyle(
//                                 color: _selectedWorkTypeIndex == 1
//                                     ? AppColors.textDark
//                                     : AppColors.textLight,
//                                 fontWeight: FontWeight.w600,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 24),
//
//               Text(
//                 isClockedIn ? 'Clock Out' : 'Clock In',
//                 style: const TextStyle(
//                   fontSize: 26,
//                   fontWeight: FontWeight.bold,
//                   color: AppColors.textDark,
//                 ),
//               ),
//               const SizedBox(height: 6),
//               Text(
//                 isClockedIn
//                     ? 'Submit your daily report to complete clock-out.'
//                     : 'Review your location and submit work description to clock in.',
//                 style: const TextStyle(
//                   fontSize: 14,
//                   color: AppColors.textMuted,
//                   height: 1.4,
//                 ),
//               ),
//               const SizedBox(height: 20),
//
//               // Total Hours Card
//               Container(
//                 width: double.infinity,
//                 padding: const EdgeInsets.all(20),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(16),
//                   boxShadow: [
//                     BoxShadow(
//                       color: Colors.black.withValues(alpha: 0.03),
//                       blurRadius: 10,
//                       offset: const Offset(0, 4),
//                     ),
//                   ],
//                 ),
//                 child: Column(
//                   children: [
//                     const Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Icon(Icons.timer, color: AppColors.primaryNavy, size: 20),
//                         SizedBox(width: 8),
//                         Text(
//                           'TOTAL HOURS WORKED',
//                           style: TextStyle(
//                             color: AppColors.primaryNavy,
//                             fontWeight: FontWeight.bold,
//                             fontSize: 13,
//                             letterSpacing: 0.5,
//                           ),
//                         ),
//                       ],
//                     ),
//                     const SizedBox(height: 16),
//                     Text(
//                       todayRecord != null
//                           ? '${todayRecord.totalHours.toStringAsFixed(1)} hrs'
//                           : '-- h --',
//                       style: const TextStyle(
//                         fontSize: 28,
//                         fontWeight: FontWeight.w500,
//                         color: AppColors.textDark,
//                       ),
//                     ),
//                     const SizedBox(height: 16),
//                     Row(
//                       children: [
//                         Expanded(
//                           child: Column(
//                             children: [
//                               const Text(
//                                 'In',
//                                 style: TextStyle(
//                                   color: AppColors.textLight,
//                                   fontSize: 13,
//                                 ),
//                               ),
//                               const SizedBox(height: 4),
//                               Text(
//                                 todayRecord?.checkInTime ?? '--:-- --',
//                                 style: const TextStyle(
//                                   color: AppColors.textDark,
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                         Container(
//                           height: 30,
//                           width: 1,
//                           color: AppColors.borderGrey,
//                         ),
//                         Expanded(
//                           child: Column(
//                             children: [
//                               const Text(
//                                 'Out',
//                                 style: TextStyle(
//                                   color: AppColors.textLight,
//                                   fontSize: 13,
//                                 ),
//                               ),
//                               const SizedBox(height: 4),
//                               Text(
//                                 todayRecord?.checkOutTime ?? '--:-- --',
//                                 style: const TextStyle(
//                                   color: AppColors.textDark,
//                                   fontSize: 15,
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 16),
//
//               // Location Card
//               Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
//                 decoration: BoxDecoration(
//                   borderRadius: BorderRadius.circular(16),
//                   gradient: const LinearGradient(
//                     colors: [Color(0xFFE0E7FF), Color(0xFFFCE7F3), Colors.white],
//                     begin: Alignment.topLeft,
//                     end: Alignment.bottomRight,
//                   ),
//                   border: Border.all(color: Colors.white, width: 2),
//                 ),
//                 child: Row(
//                   children: [
//                     const CircleAvatar(
//                       radius: 22,
//                       backgroundColor: Color(0xFFEEF2FF),
//                       child: Icon(
//                         Icons.location_on_outlined,
//                         color: AppColors.textDark,
//                       ),
//                     ),
//                     const SizedBox(width: 12),
//                     Expanded(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           Text(
//                             _selectedWorkTypeIndex == 0
//                                 ? 'GPS Location Verified'
//                                 : 'WFH Location Active',
//                             style: const TextStyle(
//                               fontWeight: FontWeight.bold,
//                               fontSize: 15,
//                               color: AppColors.textDark,
//                             ),
//                           ),
//                           const SizedBox(height: 2),
//                           Text(
//                             _selectedWorkTypeIndex == 0
//                                 ? 'HQ Building, 5th Floor'
//                                 : 'Home Office (VPN Connected)',
//                             style: const TextStyle(
//                               fontSize: 12,
//                               color: AppColors.textMuted,
//                             ),
//                           ),
//                         ],
//                       ),
//                     ),
//                     Container(
//                       padding: const EdgeInsets.symmetric(
//                         horizontal: 10,
//                         vertical: 4,
//                       ),
//                       decoration: BoxDecoration(
//                         color: AppColors.successBg,
//                         borderRadius: BorderRadius.circular(12),
//                         border: Border.all(color: const Color(0xFFA7F3D0)),
//                       ),
//                       child: const Text(
//                         'Verified',
//                         style: TextStyle(
//                           color: AppColors.successEmerald,
//                           fontSize: 11,
//                           fontWeight: FontWeight.w600,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 24),
//
//               // Description Box
//               RichText(
//                 text: const TextSpan(
//                   text: 'Daily Work Description ',
//                   style: TextStyle(
//                     fontSize: 14,
//                     fontWeight: FontWeight.bold,
//                     color: AppColors.textDark,
//                   ),
//                   children: [
//                     TextSpan(
//                       text: '*',
//                       style: TextStyle(color: AppColors.dangerRose),
//                     ),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 8),
//
//               Container(
//                 padding: const EdgeInsets.all(12),
//                 decoration: BoxDecoration(
//                   color: Colors.white,
//                   borderRadius: BorderRadius.circular(12),
//                   border: Border.all(color: AppColors.borderGrey),
//                 ),
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.end,
//                   children: [
//                     TextField(
//                       controller: _descriptionController,
//                       maxLines: 4,
//                       maxLength: 500,
//                       onChanged: (val) => setState(() {}),
//                       decoration: const InputDecoration(
//                         hintText: 'Briefly describe your tasks for today...',
//                         border: InputBorder.none,
//                         focusedBorder: InputBorder.none,
//                         enabledBorder: InputBorder.none,
//                         contentPadding: EdgeInsets.zero,
//                       ),
//                     ),
//                     Text(
//                       '${_descriptionController.text.length} / 500',
//                       style: const TextStyle(
//                         color: AppColors.textLight,
//                         fontSize: 12,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               const SizedBox(height: 24),
//
//               // Action Button
//               SizedBox(
//                 width: double.infinity,
//                 height: 52,
//                 child: ElevatedButton.icon(
//                   onPressed: isLoading
//                       ? null
//                       : () {
//                           if (isClockedIn) {
//                             context.read<AttendanceBloc>().add(
//                                   CheckOutRequestedEvent(
//                                     recordId: todayRecord.id,
//                                     description:
//                                         _descriptionController.text.trim(),
//                                   ),
//                                 );
//                           } else {
//                             context.read<AttendanceBloc>().add(
//                                   CheckInRequestedEvent(
//                                     workType: _selectedWorkTypeIndex == 0
//                                         ? 'GPS'
//                                         : 'WFH',
//                                     location: _selectedWorkTypeIndex == 0
//                                         ? 'HQ Office 5th Floor'
//                                         : 'Home Office',
//                                     description:
//                                         _descriptionController.text.trim(),
//                                   ),
//                                 );
//                           }
//                         },
//                   icon: isLoading
//                       ? const SizedBox.shrink()
//                       : Icon(
//                           isClockedIn ? Icons.logout : Icons.login,
//                           color: Colors.white,
//                           size: 20,
//                         ),
//                   label: isLoading
//                       ? const CircularProgressIndicator(
//                           valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
//                         )
//                       : Text(
//                           isClockedIn ? 'Confirm Time Out' : 'Confirm Time In',
//                           style: const TextStyle(
//                             color: Colors.white,
//                             fontSize: 16,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor:
//                         isClockedIn ? AppColors.warningAmber : AppColors.primaryNavy,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         );
//       },
//     );
//   }
// }

//-----------------------------------------------------------------------------------------------

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedWorkTypeIndex = 0; // 0 for GPS, 1 for WFH
  final TextEditingController _descriptionController = TextEditingController();

  @override
  void initState() {
    super.initState();
    context.read<AttendanceBloc>().add(LoadTodayAttendanceEvent());
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const primaryNavy = Color(0xFF002379);

    return BlocConsumer<AttendanceBloc, AttendanceState>(
      listener: (context, state) {
        if (state is AttendanceLoadedState && state.successMessage != null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.successMessage!),
              backgroundColor: AppColors.successEmerald,
            ),
          );
        } else if (state is AttendanceErrorState) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(state.message),
              backgroundColor: AppColors.dangerRose,
            ),
          );
        }
      },
      builder: (context, state) {
        final isLoading = state is AttendanceLoadingState;
        final todayRecord =
            state is AttendanceLoadedState ? state.todayRecord : null;
        final isClockedIn =
            todayRecord != null && todayRecord.checkOutTime == null;
        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Segmented Control (GPS / WFH)
              // Center(
              //   child: Container(
              //     height: 48,
              //     width: 240,
              //     padding: const EdgeInsets.all(4),
              //     decoration: BoxDecoration(
              //       color: Colors.white,
              //       borderRadius: BorderRadius.circular(12),
              //       border: Border.all(color: Colors.grey.shade300),
              //     ),
              //     child: Row(
              //       children: [
              //         Expanded(
              //           child: GestureDetector(
              //             onTap: () =>
              //                 setState(() => _selectedWorkTypeIndex = 0),
              //             child: Container(
              //               decoration: BoxDecoration(
              //                 color: _selectedWorkTypeIndex == 0
              //                     ? const Color(0xFFF1F5F9)
              //                     : Colors.transparent,
              //                 borderRadius: BorderRadius.circular(8),
              //               ),
              //               alignment: Alignment.center,
              //               child: Text(
              //                 'GPS',
              //                 style: TextStyle(
              //                   color: _selectedWorkTypeIndex == 0
              //                       ? Colors.grey.shade800
              //                       : Colors.grey.shade500,
              //                   fontWeight: FontWeight.w600,
              //                 ),
              //               ),
              //             ),
              //           ),
              //         ),
              //         Expanded(
              //           child: GestureDetector(
              //             onTap: () =>
              //                 setState(() => _selectedWorkTypeIndex = 1),
              //             child: Container(
              //               decoration: BoxDecoration(
              //                 color: _selectedWorkTypeIndex == 1
              //                     ? const Color(0xFFF1F5F9)
              //                     : Colors.transparent,
              //                 borderRadius: BorderRadius.circular(8),
              //               ),
              //               alignment: Alignment.center,
              //               child: Text(
              //                 'WFH',
              //                 style: TextStyle(
              //                   color: _selectedWorkTypeIndex == 1
              //                       ? Colors.grey.shade800
              //                       : Colors.grey.shade500,
              //                   fontWeight: FontWeight.w600,
              //                 ),
              //               ),
              //             ),
              //           ),
              //         ),
              //       ],
              //     ),
              //   ),
              // ),
              // const SizedBox(height: 24),

              // Page Title & Subtitle
              const Text(
                'Clock In',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1E293B),
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Review your daily summary and submit your work description.',
                style: TextStyle(
                  fontSize: 14,
                  color: Color(0xFF64748B),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 20),

              // Total Hours Worked Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.03),
                      blurRadius: 10,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.timer,
                          color: primaryNavy,
                          size: 20,
                        ),
                        SizedBox(width: 8),
                        Text(
                          'TOTAL HOURS WORKED',
                          style: TextStyle(
                            color: primaryNavy,
                            fontWeight: FontWeight.bold,
                            fontSize: 13,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      '-- h --',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w400,
                        color: Color(0xFF475569),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: const [
                                  Text(
                                    'In ',
                                    style: TextStyle(
                                      color: Color(0xFF94A3B8),
                                      fontSize: 13,
                                    ),
                                  ),
                                  Text(
                                    'm',
                                    style: TextStyle(
                                      color: Color(0xFF475569),
                                      fontWeight: FontWeight.w500,
                                      fontSize: 15,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 4),
                              const Text(
                                '--:-- --',
                                style: TextStyle(
                                  color: Color(0xFF475569),
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          height: 30,
                          width: 1,
                          color: const Color(0xFFE2E8F0),
                        ),
                        Expanded(
                          child: Column(
                            children: const [
                              Text(
                                'Out',
                                style: TextStyle(
                                  color: Color(0xFF94A3B8),
                                  fontSize: 13,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                '--:-- --',
                                style: TextStyle(
                                  color: Color(0xFF475569),
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    )
                  ],
                ),
              ),
              const SizedBox(height: 16),

              Center(
                child: Container(
                  height: 48,
                  width: 240,
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade300),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () =>
                              setState(() => _selectedWorkTypeIndex = 0),
                          child: Container(
                            decoration: BoxDecoration(
                              color: _selectedWorkTypeIndex == 0
                                  ? const Color(0xFFF1F5F9)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              'GPS',
                              style: TextStyle(
                                color: _selectedWorkTypeIndex == 0
                                    ? Colors.grey.shade800
                                    : Colors.grey.shade500,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: GestureDetector(
                          onTap: () =>
                              setState(() => _selectedWorkTypeIndex = 1),
                          child: Container(
                            decoration: BoxDecoration(
                              color: _selectedWorkTypeIndex == 1
                                  ? const Color(0xFFF1F5F9)
                                  : Colors.transparent,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            alignment: Alignment.center,
                            child: Text(
                              'WFH',
                              style: TextStyle(
                                color: _selectedWorkTypeIndex == 1
                                    ? Colors.grey.shade800
                                    : Colors.grey.shade500,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // Location Verified Card with Gradient
              _selectedWorkTypeIndex == 0
                  ? Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        gradient: const LinearGradient(
                          colors: [
                            Color(0xFFE0E7FF),
                            Color(0xFFFCE7F3),
                            Colors.white,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        border: Border.all(color: Colors.white, width: 2),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.03),
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Row(
                        children: [
                          Stack(
                            clipBehavior: Clip.none,
                            children: [
                              CircleAvatar(
                                radius: 22,
                                backgroundColor: const Color(0xFFEEF2FF),
                                child: const Icon(
                                  Icons.location_on_outlined,
                                  color: Color(0xFF1E293B),
                                ),
                              ),
                              Positioned(
                                top: 0,
                                right: 2,
                                child: Container(
                                  width: 10,
                                  height: 10,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF10B981),
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                        color: Colors.white, width: 2),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text(
                                  'Location Verified',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  'HQ Building, 5th Floor',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFF64748B),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: const Color(0xFFECFDF5),
                              borderRadius: BorderRadius.circular(12),
                              border:
                                  Border.all(color: const Color(0xFFA7F3D0)),
                            ),
                            child: const Text(
                              'In\nRange',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color(0xFF059669),
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                height: 1.1,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          IconButton(
                            icon: const Icon(Icons.refresh,
                                color: Color(0xFF94A3B8)),
                            onPressed: () {},
                            constraints: const BoxConstraints(),
                            padding: EdgeInsets.zero,
                          ),
                        ],
                      ),
                    )
                  : SizedBox.shrink(),
              SizedBox(height: _selectedWorkTypeIndex == 0 ? 24 : 0),
              // Input Label
              RichText(
                text: const TextSpan(
                  text: 'Daily Work Description ',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1E293B),
                  ),
                  children: [
                    TextSpan(
                      text: '*',
                      style: TextStyle(color: Colors.red),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),

              // Description Text Box Card
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    TextField(
                      controller: _descriptionController,
                      maxLines: 4,
                      maxLength: 500,
                      onChanged: (val) => setState(() {}),
                      buildCounter: (
                        context, {
                        required currentLength,
                        required isFocused,
                        maxLength,
                      }) =>
                          null,
                      // Hide default counter
                      decoration: const InputDecoration(
                        hintText:
                            'Briefly describe the tasks you completed today...',
                        hintStyle: TextStyle(
                          color: Color(0xFF94A3B8),
                          fontSize: 14,
                        ),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                    Text(
                      '${_descriptionController.text.length} / 500',
                      style: const TextStyle(
                        color: Color(0xFF94A3B8),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Confirm Button
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: isLoading
                      ? null
                      : () {
                          if (isClockedIn) {
                            context.read<AttendanceBloc>().add(
                                  CheckOutRequestedEvent(
                                    recordId: todayRecord.id,
                                    description:
                                        _descriptionController.text.trim(),
                                  ),
                                );
                          } else {
                            context.read<AttendanceBloc>().add(
                                  CheckInRequestedEvent(
                                    workType: _selectedWorkTypeIndex == 0
                                        ? 'GPS'
                                        : 'WFH',
                                    location: _selectedWorkTypeIndex == 0
                                        ? 'HQ Office 5th Floor'
                                        : 'Home Office',
                                    description:
                                        _descriptionController.text.trim(),
                                  ),
                                );
                          }
                        },
                  icon: const Icon(Icons.logout, color: Colors.white, size: 20),
                  label: isLoading
                      ? const CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(Colors.white),
                        )
                      : Text(
                          isClockedIn ? 'Confirm Time Out' : 'Confirm Time In',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isClockedIn
                        ? AppColors.warningAmber
                        : AppColors.primaryNavy,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        );
      },
    );
  }
}
