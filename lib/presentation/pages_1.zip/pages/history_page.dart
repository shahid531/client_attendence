import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '../../core/constants/app_colors.dart';
import '../../domain/entities/attendance_record.dart';
import '../blocs/attendance/attendance_bloc.dart';
import '../blocs/attendance/attendance_event.dart';
import '../blocs/attendance/attendance_state.dart';

// class HistoryPage extends StatefulWidget {
//   const HistoryPage({super.key});
//
//   @override
//   State<HistoryPage> createState() => _HistoryPageState();
// }
//
// class _HistoryPageState extends State<HistoryPage> {
//   String _selectedFilter = 'All';
//
//   @override
//   void initState() {
//     super.initState();
//     context.read<AttendanceBloc>().add(LoadAttendanceHistoryEvent());
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return BlocBuilder<AttendanceBloc, AttendanceState>(
//       builder: (context, state) {
//         if (state is AttendanceLoadingState) {
//           return const Center(child: CircularProgressIndicator());
//         }
//
//         final history = state is AttendanceLoadedState ? state.history : [];
//         final filteredList = history.where((item) {
//           if (_selectedFilter == 'All') return true;
//           if (_selectedFilter == 'GPS') return item.workType == 'GPS';
//           if (_selectedFilter == 'WFH') return item.workType == 'WFH';
//           if (_selectedFilter == 'Half Day') return item.status == 'Half Day';
//           return true;
//         }).toList();
//
//         return Column(
//           children: [
//             // Filter Pills Header
//             Container(
//               height: 56,
//               color: Colors.white,
//               child: ListView(
//                 scrollDirection: Axis.horizontal,
//                 padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
//                 children: ['All', 'GPS', 'WFH', 'Half Day'].map((filter) {
//                   final isSelected = _selectedFilter == filter;
//                   return Padding(
//                     padding: const EdgeInsets.only(right: 8.0),
//                     child: ChoiceChip(
//                       label: Text(filter),
//                       selected: isSelected,
//                       onSelected: (selected) {
//                         if (selected) {
//                           setState(() => _selectedFilter = filter);
//                         }
//                       },
//                       selectedColor: AppColors.primaryNavy,
//                       labelStyle: TextStyle(
//                         color: isSelected ? Colors.white : AppColors.textDark,
//                         fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
//                       ),
//                       backgroundColor: const Color(0xFFF1F5F9),
//                     ),
//                   );
//                 }).toList(),
//               ),
//             ),
//             const Divider(height: 1, color: AppColors.borderGrey),
//
//             // History List
//             Expanded(
//               child: filteredList.isEmpty
//                   ? Center(
//                       child: Column(
//                         mainAxisAlignment: MainAxisAlignment.center,
//                         children: const [
//                           Icon(Icons.history, size: 48, color: AppColors.textLight),
//                           SizedBox(height: 12),
//                           Text(
//                             'No attendance records found',
//                             style: TextStyle(
//                               color: AppColors.textMuted,
//                               fontSize: 16,
//                             ),
//                           ),
//                         ],
//                       ),
//                     )
//                   : ListView.separated(
//                       padding: const EdgeInsets.all(16),
//                       itemCount: filteredList.length,
//                       separatorBuilder: (_, __) => const SizedBox(height: 12),
//                       itemBuilder: (context, index) {
//                         final record = filteredList[index];
//                         return _buildAttendanceCard(record);
//                       },
//                     ),
//             ),
//           ],
//         );
//       },
//     );
//   }
//
//   Widget _buildAttendanceCard(AttendanceRecord record) {
//     final dateStr = DateFormat('EEE, MMM dd, yyyy').format(record.date);
//
//     return Container(
//       padding: const EdgeInsets.all(16),
//       decoration: BoxDecoration(
//         color: Colors.white,
//         borderRadius: BorderRadius.circular(14),
//         border: Border.all(color: AppColors.borderGrey),
//       ),
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//         children: [
//           Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Row(
//                 children: [
//                   const Icon(Icons.calendar_today_outlined,
//                       size: 16, color: AppColors.primaryNavy),
//                   const SizedBox(width: 6),
//                   Text(
//                     dateStr,
//                     style: const TextStyle(
//                       fontWeight: FontWeight.bold,
//                       fontSize: 15,
//                       color: AppColors.textDark,
//                     ),
//                   ),
//                 ],
//               ),
//               Container(
//                 padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
//                 decoration: BoxDecoration(
//                   color: record.workType == 'GPS'
//                       ? const Color(0xFFEFF6FF)
//                       : const Color(0xFFF0FDF4),
//                   borderRadius: BorderRadius.circular(12),
//                   border: Border.all(
//                     color: record.workType == 'GPS'
//                         ? const Color(0xFFBFDBFE)
//                         : const Color(0xFFA7F3D0),
//                   ),
//                 ),
//                 child: Text(
//                   record.workType,
//                   style: TextStyle(
//                     fontSize: 11,
//                     fontWeight: FontWeight.bold,
//                     color: record.workType == 'GPS'
//                         ? AppColors.primaryBlue
//                         : AppColors.successEmerald,
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           const SizedBox(height: 12),
//           Row(
//             children: [
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text('Clock In',
//                         style: TextStyle(color: AppColors.textLight, fontSize: 12)),
//                     const SizedBox(height: 2),
//                     Text(record.checkInTime,
//                         style: const TextStyle(
//                             fontWeight: FontWeight.w600, color: AppColors.textDark)),
//                   ],
//                 ),
//               ),
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text('Clock Out',
//                         style: TextStyle(color: AppColors.textLight, fontSize: 12)),
//                     const SizedBox(height: 2),
//                     Text(record.checkOutTime ?? 'Active Now',
//                         style: const TextStyle(
//                             fontWeight: FontWeight.w600, color: AppColors.textDark)),
//                   ],
//                 ),
//               ),
//               Expanded(
//                 child: Column(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   children: [
//                     const Text('Total',
//                         style: TextStyle(color: AppColors.textLight, fontSize: 12)),
//                     const SizedBox(height: 2),
//                     Text('${record.totalHours.toStringAsFixed(1)} hrs',
//                         style: const TextStyle(
//                             fontWeight: FontWeight.bold, color: AppColors.primaryNavy)),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//           if (record.description.isNotEmpty) ...[
//             const SizedBox(height: 10),
//             Container(
//               width: double.infinity,
//               padding: const EdgeInsets.all(8),
//               decoration: BoxDecoration(
//                 color: const Color(0xFFF8FAFC),
//                 borderRadius: BorderRadius.circular(8),
//               ),
//               child: Text(
//                 record.description,
//                 style: const TextStyle(
//                   fontSize: 13,
//                   color: AppColors.textMuted,
//                 ),
//               ),
//             ),
//           ],
//         ],
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key});

  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  // Dropdown State
  String _selectedPeriod = 'Custom';
  final List<String> _periodOptions = ['This Month', 'Last Month', 'Custom'];

  // Date Pickers State
  DateTime _fromDate = DateTime(2023, 10, 1);
  DateTime _toDate = DateTime(2023, 10, 26);

  Future<void> _selectDate(BuildContext context, bool isFromDate) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: isFromDate ? _fromDate : _toDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
    );
    if (picked != null) {
      setState(() {
        if (isFromDate) {
          _fromDate = picked;
        } else {
          _toDate = picked;
        }
      });
    }
  }

  String _formatDate(DateTime date) {
    return "${date.month.toString().padLeft(2, '0')}/${date.day.toString().padLeft(2, '0')}/${date.year}";
  }

  @override
  Widget build(BuildContext context) {
    const primaryNavy = Color(0xFF002379);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header Row: Title & Export Button
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Attendance Log',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1E293B),
                ),
              ),
              ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.download, size: 16, color: primaryNavy),
                label: const Text(
                  'Export',
                  style: TextStyle(
                    color: primaryNavy,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFEEF2FF),
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Filter Dropdown
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
            decoration: BoxDecoration(
              color: const Color(0xFFEEF2FF),
              borderRadius: BorderRadius.circular(20),
            ),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                value: _selectedPeriod,
                icon: const Icon(Icons.keyboard_arrow_down, color: Color(0xFF475569)),
                style: const TextStyle(
                  color: Color(0xFF1E293B),
                  fontWeight: FontWeight.w500,
                  fontSize: 14,
                ),
                onChanged: (String? newValue) {
                  if (newValue != null) {
                    setState(() {
                      _selectedPeriod = newValue;
                    });
                  }
                },
                items: _periodOptions.map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Conditional Date Range Card (Displayed ONLY when 'Custom' is selected)
          if (_selectedPeriod == 'Custom') ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Select Date Range',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: Color(0xFF1E293B),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _selectedPeriod = 'This Month'; // Resets dropdown to hide panel
                          });
                        },
                        child: const CircleAvatar(
                          radius: 11,
                          backgroundColor: Color(0xFFCBD5E1),
                          child: Icon(Icons.close, size: 14, color: Colors.white),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'FROM',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            const SizedBox(height: 6),
                            InkWell(
                              onTap: () => _selectDate(context, true),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 10),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEDF2F7),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Icon(Icons.calendar_today_outlined,
                                        size: 16, color: Color(0xFF64748B)),
                                    Text(
                                      _formatDate(_fromDate),
                                      style: const TextStyle(
                                        fontSize: 13,
                                        color: Color(0xFF1E293B),
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    const Icon(Icons.calendar_month,
                                        size: 16, color: Color(0xFF1E293B)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'TO',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF64748B),
                              ),
                            ),
                            const SizedBox(height: 6),
                            InkWell(
                              onTap: () => _selectDate(context, false),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10, vertical: 10),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEDF2F7),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Icon(Icons.calendar_today_outlined,
                                        size: 16, color: Color(0xFF64748B)),
                                    Text(
                                      _formatDate(_toDate),
                                      style: const TextStyle(
                                        fontSize: 13,
                                        color: Color(0xFF1E293B),
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    const Icon(Icons.calendar_month,
                                        size: 16, color: Color(0xFF1E293B)),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    height: 42,
                    child: ElevatedButton(
                      onPressed: () {},
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryNavy,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        elevation: 0,
                      ),
                      child: const Text(
                        'Apply Range',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            const SizedBox(height: 16),
          ],

          // Summary Stats Card
          Container(
            padding: const EdgeInsets.symmetric(vertical: 16),
            decoration: BoxDecoration(
              color: const Color(0xFFEEF2FF),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                _buildStatItem('18', 'Present', const Color(0xFF2563EB)),
                _buildDivider(),
                _buildStatItem('2', 'WFH', const Color(0xFF1E293B)),
                _buildDivider(),
                _buildStatItem('1', 'Absent', const Color(0xFFDC2626)),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Attendance Logs List
          _buildAttendanceCard(
            accentColor: const Color(0xFF2563EB),
            dayLabel: 'TODAY',
            dateStr: 'Oct 26, 2023',
            clientStr: 'Client: Acme Corp (Site B)',
            statusBadge: _buildStatusBadge(
              label: 'Present',
              icon: Icons.check_circle_outline,
              bgColor: const Color(0xFFDCFCE7),
              textColor: const Color(0xFF15803D),
            ),
            inTime: '08:55 AM',
            outTime: '05:05 PM',
          ),
          _buildAttendanceCard(
            accentColor: const Color(0xFFD97706),
            dayLabel: 'YESTERDAY',
            dateStr: 'Oct 25, 2023',
            clientStr: 'Remote Setup',
            statusBadge: _buildStatusBadge(
              label: 'WFH Approved',
              icon: Icons.home,
              bgColor: const Color(0xFFFEF3C7),
              textColor: const Color(0xFFB45309),
            ),
            inTime: '09:00 AM',
            outTime: '06:00 PM',
          ),
          _buildAttendanceCard(
            accentColor: const Color(0xFF475569),
            dayLabel: 'MON',
            dateStr: 'Oct 24, 2023',
            clientStr: 'Client: Globex Inc.',
            statusBadge: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFE0E7FF),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.more_horiz, size: 14, color: primaryNavy),
                  SizedBox(width: 4),
                  Text(
                    'Regularization\nPending',
                    style: TextStyle(
                      color: primaryNavy,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                      height: 1.1,
                    ),
                  ),
                ],
              ),
            ),
            inTime: '08:45 AM',
            customOutWidget: Row(
              children: const [
                Icon(Icons.warning_amber_rounded, size: 16, color: Color(0xFFDC2626)),
                SizedBox(width: 4),
                Text(
                  'Missing Out',
                  style: TextStyle(
                    color: Color(0xFFDC2626),
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          _buildAttendanceCard(
            accentColor: const Color(0xFFDC2626),
            dayLabel: 'FRI',
            dateStr: 'Oct 20, 2023',
            clientStr: 'Scheduled: Acme Corp',
            statusBadge: _buildStatusBadge(
              label: 'Absent',
              icon: Icons.cancel_outlined,
              bgColor: const Color(0xFFFEE2E2),
              textColor: const Color(0xFFB91C1C),
            ),
            isNoRecord: true,
          ),
          _buildAttendanceCard(
            accentColor: const Color(0xFF2563EB),
            dayLabel: 'THU',
            dateStr: 'Oct 19, 2023',
            clientStr: 'Client: Initech (HQ)',
            statusBadge: _buildStatusBadge(
              label: 'Present',
              icon: Icons.check_circle_outline,
              bgColor: const Color(0xFFDCFCE7),
              textColor: const Color(0xFF15803D),
            ),
            inTime: '08:50 AM',
            outTime: '05:15 PM',
          ),
          const SizedBox(height: 12),

          // Load Older Records Button
          Center(
            child: TextButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.refresh, size: 18, color: primaryNavy),
              label: const Text(
                'Load Older Records',
                style: TextStyle(
                  color: primaryNavy,
                  fontWeight: FontWeight.w600,
                  fontSize: 14,
                ),
              ),
              style: TextButton.styleFrom(
                backgroundColor: const Color(0xFFE0E7FF),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  // Summary Stat Helper
  Widget _buildStatItem(String count, String label, Color color) {
    return Expanded(
      child: Column(
        children: [
          Text(
            count,
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: const TextStyle(
              fontSize: 13,
              color: Color(0xFF64748B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDivider() {
    return Container(
      height: 24,
      width: 1,
      color: const Color(0xFFCBD5E1),
    );
  }

  // Status Badge Builder
  Widget _buildStatusBadge({
    required String label,
    required IconData icon,
    required Color bgColor,
    required Color textColor,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: textColor),
          const SizedBox(width: 4),
          Text(
            label,
            style: TextStyle(
              color: textColor,
              fontSize: 12,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // Card Item Builder
  Widget _buildAttendanceCard({
    required Color accentColor,
    required String dayLabel,
    required String dateStr,
    required String clientStr,
    required Widget statusBadge,
    String? inTime,
    String? outTime,
    Widget? customOutWidget,
    bool isNoRecord = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.02),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              width: 4,
              color: accentColor,
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(14.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              dayLabel,
                              style: const TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF94A3B8),
                              ),
                            ),
                            const SizedBox(height: 2),
                            Text(
                              dateStr,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                          ],
                        ),
                        statusBadge,
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      clientStr,
                      style: const TextStyle(
                        fontSize: 13,
                        color: Color(0xFF64748B),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (isNoRecord)
                      const Row(
                        children: [
                          Text(
                            '—  ',
                            style: TextStyle(color: Color(0xFF94A3B8)),
                          ),
                          Text(
                            'No Record',
                            style: TextStyle(
                              color: Color(0xFF94A3B8),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      )
                    else
                      Row(
                        children: [
                          const Icon(Icons.login_rounded, size: 16, color: Color(0xFF64748B)),
                          const SizedBox(width: 4),
                          Text(
                            inTime ?? '',
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF1E293B),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Container(height: 12, width: 1, color: const Color(0xFFCBD5E1)),
                          const SizedBox(width: 16),
                          if (customOutWidget != null)
                            customOutWidget
                          else ...[
                            const Icon(Icons.logout_rounded, size: 16, color: Color(0xFF64748B)),
                            const SizedBox(width: 4),
                            Text(
                              outTime ?? '',
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                          ],
                        ],
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
